#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "av.h"
#include <QCursor>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

protected:
    void mouseMoveEvent(QMouseEvent *event) override;


public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void updateScore();
    void missedDuckScored();


private:

        int missedDuckCount = 0;
        int DuckCount = 0;
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
