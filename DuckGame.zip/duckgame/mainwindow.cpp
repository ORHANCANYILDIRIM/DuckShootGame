#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "av.h"
#include <QRandomGenerator>
#include <QTimer>
#include <QPalette>
#include <QPixmap>
#include <QString>
#include <QDebug>
#include <QMouseEvent> // Mouse olaylarını takip etmek için gerekli kütüphane

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    ui->label->setStyleSheet("background-color: white; color: black;");
    ui->label_2->setText("Kaçan Ördekler: 0");
    ui->label_3->setText("Vurulan Ördekler: 0");
    showMaximized();

    // Arkaplan resmi ekleme
    QPixmap background(":/res/arkaPlan.png");
    QPalette palette;
    palette.setBrush(QPalette::Background, background);
    this->setPalette(palette);

    const int numLabels = 50;
    int delay = 0;
    int missedDuckCount = 0;
    int DuckCount = 0;

    for (int i = 0; i < numLabels; ++i) {
        av *avlar = new av(this, this);

        int labelWidth = QRandomGenerator::global()->bounded(25, 26);
        int randomX = QRandomGenerator::global()->bounded(width() - 250);
        int randomY = QRandomGenerator::global()->bounded(-1920, height() - 800);

        avlar->setGeometry(randomX, randomY, labelWidth, 25);

        QTimer *timer = new QTimer(this);

        timer->start(delay);
        delay += 1000;

        connect(avlar, &av::clicked, this, &MainWindow::updateScore);
        connect(avlar, &av::missedDuckScore, this, &MainWindow::missedDuckScored);
    }
}

MainWindow::~MainWindow() {
    delete ui;
}
void MainWindow::missedDuckScored() {
    qDebug() << "onTimeout called";

    int missedDuckCount = ui->label_2->text().split(' ').last().toInt();
    missedDuckCount++;
    ui->label_2->setText("Kaçan Ördekler: " + QString::number(missedDuckCount));
}

void MainWindow::updateScore() {
    qDebug() << "updateScore called";

    int DuckCount = ui->label_3->text().split(' ').last().toInt();
    DuckCount++;
    ui->label_3->setText("Vurulan Ördekler: " + QString::number(DuckCount));
}

void MainWindow::mouseMoveEvent(QMouseEvent *event) {
    // İkon oluştur
    QPixmap customCursor(":/res/ak47.png");
    if (!customCursor.isNull()) {
        QPoint cursorPos = event->pos(); // Fare konumu alınır
               QPoint customCursorPos = cursorPos + QPoint(0.5, 0); // İkona ofset uygula
        // İkonu fare imleci olarak ayarla
        setCursor(QCursor(customCursor,0,0));
        QCursor::setPos(mapToGlobal(customCursorPos)); // İmlecin ekran konumunu ayarla
    }

    // Diğer işlemler burada devam eder...
    QMainWindow::mouseMoveEvent(event);
}
