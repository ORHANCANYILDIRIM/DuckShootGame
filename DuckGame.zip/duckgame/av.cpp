#include "av.h"
#include "mainwindow.h"
#include <QTimer>
#include <QDebug>

av::av(MainWindow *frm, QWidget *parent) : QLabel(parent), frm(frm) {
    QPixmap defaultImage(":/res/ordek.png");
    defaultImage = defaultImage.scaled(size(), Qt::KeepAspectRatio);
    setPixmap(defaultImage);

    setGeometry(frm->size().width() / 2, frm->size().height() / 2, 100, 50);
    setFrameShape(QFrame::Box);
    show();

    connect(this, &av::clickedAndShowImage, frm, [=](QPoint pos) {
           QPixmap tempImage(":/res/vurulma.png"); // Geçici resim

           int desiredWidth = 30; // pixel ayarlıom
               int desiredHeight = tempImage.height() * desiredWidth / tempImage.width(); // yüksekliği hesapla
               tempImage = tempImage.scaled(desiredWidth, desiredHeight, Qt::KeepAspectRatio);

           QLabel *tempLabel = new QLabel(frm);
           tempLabel->setPixmap(tempImage);

           QPoint globalPos = mapToGlobal(pos); // tıklanan yerin globalkonumu
              QPoint labelPos = frm->mapFromGlobal(globalPos); // konumu main windowa
              int labelWidth = tempImage.width();
              int labelHeight = tempImage.height();
              tempLabel->setGeometry(labelPos.x(), labelPos.y(), labelWidth, labelHeight);


           tempLabel->show();
           QTimer::singleShot(150, tempLabel, &QWidget::hide); //görünme süresi
       });

    zaman = new QTimer(this);
    connect(zaman, SIGNAL(timeout()), this, SLOT(hareketlendir()));
    zaman->start(50);
}

void av::mousePressEvent(QMouseEvent *event) {
    QPoint pos = event->pos(); // Tıklama noktası
    emit clickedAndShowImage(pos); //
    zaman->stop();
    hide();
    emit clicked();
    deleteLater();
}

void av::hareketlendir() {
    setGeometry(x(), y() + 10, width(), height());
    if (geometry().y() > 1000) {
        durdur();
    }
}

void av::durdur() {
    qDebug() << "Stopping timer";
    zaman->stop();
    emit missedDuckScore();
}
