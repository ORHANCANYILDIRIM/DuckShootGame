#ifndef AV_H
#define AV_H

#include <QLabel>
#include <QMouseEvent>

class MainWindow;

class av : public QLabel
{
    Q_OBJECT
public:
    explicit av(MainWindow *frm, QWidget *parent = nullptr);

signals:
    void clickedAndShowImage(QPoint pos);


protected:
    void mousePressEvent(QMouseEvent *event) override;

private:
    QTimer *zaman;

        MainWindow *frm;

private slots:
    void hareketlendir();
    void durdur();




signals:
  void clicked();
 void missedDuckScore();
};

#endif // AV_H
